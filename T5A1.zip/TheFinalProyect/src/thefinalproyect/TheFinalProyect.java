
package thefinalproyect;

import java.util.Scanner;

public class TheFinalProyect {

    public static void main(String[] args) {
       Scanner s = new Scanner (System.in);
       String nombre;
       String equipo;
       
       
           
        System.out.println("Hola bienvenido a el Mundialito :)");
        
                System.out.println("\n Como puedo llamarte?: ");
                nombre = s.nextLine();
                
                System.out.println("Hola " + nombre + " \nEn que seleccion estas interesado?"
                        + "\n1.Mexico"
                        + "\n2.Costa Rica"
                        + "\n3.Estados Unidos"
                        + "\n4.Canada");
                
                int equipos = s.nextInt();
                
                switch(equipos) {
                    case 1:
                        Mexico();
                        break;
                        
                    case 2: 
                        Costa Rica();
                        break;
 
                    case 3:
                        Estados Unidos ();
                         break;
                    
                    case 4: 
                        Canada();
                        break;
                }
               public static void Mexico(){
                   s
               }
                 
       
      
                
                
              
                
        
        
        
        
        
        
    }
    
}
