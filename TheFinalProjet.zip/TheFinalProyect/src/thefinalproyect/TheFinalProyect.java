
package thefinalproyect;
import java.util.Scanner;

/** *
 * @author Raul */
public class TheFinalProyect {


    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        Variables v =new Variables();
        String nombre;
        int equipos;
        
        
        do {
            System.out.println("Hola bienvenido a el Mundialito :)");
           v.getNombre();
            System.out.println("\n Como puedo llamarte?: ");
            nombre=s.next();
            v.setNombre(nombre);
            System.out.println("Hola " + v.getNombre() + " \nEn que seleccion estas interesado?"
                    + "\n1.Mexico"
                    + "\n2.Costa Rica"
                    + "\n3.Estados Unidos"
                    + "\n4.Apuesta"
                    + "\n5.Salir");
            equipos=s.nextInt();
            v.setEquipos(equipos);
            
            v.getEquipos();

            switch (v.getEquipos()) {
                case 1:
                    v.mexico();
                    break;

                case 2:
                    v.costaRica();
                    break;

                case 3:
                    v.eua();
                    break;

                case 4:
                    v.apuesta();
                    break;

                case 5:
                    System.out.println("gracias por utilizar nuestro programa :) ");
                    break;

                default:
                    System.out.println("favor de ingresar un valor corectamente");
                    break;

            }

        } while (v.getEquipos() != 100);
    }
    
}
