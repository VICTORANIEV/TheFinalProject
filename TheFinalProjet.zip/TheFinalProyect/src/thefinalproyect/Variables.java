package thefinalproyect;

import java.util.Scanner;

    public class Variables {
         private String nombre;
        private String equipo;
        private String canada;
        private String costaRica;
        private String eua;
        private String mexico;
        private int equipos;
        private int apuesta;
        private float apuesta2;
        private int apuesta3;
        private int i;
        private int descuento;

    Variables() {
    }

  
        
    public void Variables (){}
    
    
    public  void mexico() {

        System.out.println("Lista de Jugadores\n"
                + "1.	Guillermo Ochoa	\n"
                + "2.	Alfredo Talavera\n"
                + "3.	Rodolfo Cota		\n"
                + "4.	Kevin Álvarez		\n"
                + "5.	Néstor Araujo		\n"
                + "6.	Jesús Gallardo	\n"
                + "7.	Héctor Moreno		\n"
                + "8.	César Montes	\n"
                + "9.	Gerardo Arteaga		\n"
                + "10.	Jorge Sánchez		\n"
                + "11.	Johan Vásquez	\n"
                + "12.	Luis Romo	\n"
                + "13.	Uriel Antuna	\n"
                + "14.	Luis Chávez	\n"
                + "15.	Carlos Rodríguez\n"
                + "16.	Edson Álvarez	\n"
                + "17.	Héctor Herrera	\n"
                + "18.	Erik Gutiérrez	\n"
                + "19.	Orbelín Pineda\n"
                + "20.	Roberto Alvarado	\n"
                + "21.	Andrés Guardado\n"
                + "22.	Rogelio Funes Mori\n"
                + "23.	Henry Martín	\n"
                + "24.	Raúl Jiménez	\n"
                + "25.	Hirving Lozano	\n"
                + "26.	Alexis Vega");

        System.out.println("Grupo:"
                + "\nMexico se encuentra en el grupo C conformado por:"
                + "\nArgentina"
                + "\nPolonia"
                + "\nMexico"
                + "\nArabia Saudita");

        System.out.println("Partidos");
    }

    public  void costaRica() {
        System.out.println("Lista de Jugadores\n"
                + "1.	Keylor Navas \n"
                + "2.	Esteban Alvarado \n"
                + "3.	Patrick Sequeira \n"
                + "4.	DEFENSAS\n"
                + "5.	Francisco Calvo\n"
                + "6.	Juan Pablo Vargas\n"
                + "7.	Kendall Watson\n"
                + "8.	Óscar Duarte\n"
                + "9.	Daniel Chacón\n"
                + "10.	Keysher Fuller \n"
                + "11.	Carlos Martínez\n"
                + "12.	Bryan Oviedo (Real Salt Lake)\n"
                + "13.	Ronald Matarrita (Cincinnati)\n"
                + "14.	Yeltsin Tejeda (Herediano)\n"
                + "15.	Celso Borges (Alajuelense)\n"
                + "16.	Youstin Salas (Saprissa)\n"
                + "17.	Roan Wilson (Municipal Grecia)\n"
                + "18.	Gerson Torres (Herediano)\n"
                + "19.	Douglas López (Herediano)\n"
                + "20.	Jewison Bennette (Sunderland)\n"
                + "21.	Álvaro Zamora (Saprissa)\n"
                + "22.	Anthony Hernández (Puntarenas FC)\n"
                + "23.	Brandon Aguilera (Nottingham Forest)\n"
                + "24.	Bryan Ruiz (Alajuelense)\n"
                + "25.	Joel Campbell (León)\n"
                + "26.	Anthony Contreras (Herediano)\n"
                + "27.	Johan Venegas (Alajuelense)");

        System.out.println("Grupo:"
                + "\nCosta Rica se encuentra en el grupo E conformado por:"
                + "\nEspaña"
                + "\nJapon"
                + "\nAlemania"
                + "\nCosta Rica");

        System.out.println("Partidos");
    }

    public  void eua() {
        System.out.println("Lista de Jugadores"
                + "1.	Ethan Horvat	\n"
                + "2.	Sean Johnson	\n"
                + "3.	Matt Turner	\n"
                + "4.	Cameron Carter-Vickers	\n"
                + "5.	Sergiño Dest	\n"
                + "6.	Aaron Long	\n"
                + "7.	Shaq Moore	\n"
                + "8.	Tim Ream	\n"
                + "9.	Antonee Robinson	\n"
                + "10.	Joe Scally	\n"
                + "11.	DeAndre Yedlin	\n"
                + "12.	Walker Zimmerman	\n"
                + "13.	Brenden Aaronson	\n"
                + "14.	Kellyn Acosta	\n"
                + "15.	Tyler Adams	\n"
                + "16.	Luca de la Torre	\n"
                + "17.	Weston McKennie	\n"
                + "18.	Yunus Musah	\n"
                + "19.	Cristian Roldan	\n"
                + "20.	Jesús Ferreira	\n"
                + "21.	Jordan Morris	\n"
                + "22.	Christian Pulisic	\n"
                + "23.	Gio Reyna	\n"
                + "24.	Josh Sargent	\n"
                + "25.	Tim Weah	\n"
                + "26.	Haji Wright");

        System.out.println("Grupo:"
                + "\nEstados Unidos se encuentra en el grupo B conformado por:"
                + "\nInglaterra"
                + "\nEstados Unidos"
                + "\nIran"
                + "\nGales");
       
        System.out.println("Partidos");
    }

    public  void canada() {
        System.out.println("Lista de Jugadores");

        System.out.println("Grupo");

        System.out.println("Partidos");
    }

    public  void apuesta () {
        Scanner s = new Scanner(System.in);
        Variables v= new Variables();
       
        System.out.println("el costo minimo por la apuesta es $200");
        System.out.println("ingrese por favor las veces qeu quiere hacer la apuesta");
        apuesta2=s.nextInt();
        for ( i=1 ; i <= apuesta2; i++) {
           apuesta=apuesta+200;
        }
        System.out.println(apuesta);
        if (apuesta > 500) {
            descuento = (int) (apuesta * 0.1);
           apuesta = apuesta - descuento;
            System.out.println("se ha hecho el descuento de " + descuento + " por lo tanto , usted pagara " + apuesta);
        } else {
            System.out.println("el total es " + apuesta);
        }

    }

    public Variables(String nombre, String equipo, String canada, String costaRica, String eua, String mexico, int equipos, float apuesta2, int apuesta3, int i, int descuento) {
        this.nombre = nombre;
        this.equipo = equipo;
        this.canada = canada;
        this.costaRica = costaRica;
        this.eua = eua;
        this.mexico = mexico;
        this.equipos = equipos;
        this.apuesta2 = apuesta2;
        this.apuesta3 = apuesta3;
        this.i = i;
        this.descuento = descuento;
    }

    public int getDescuento() {
        return descuento;
    }

    public void setDescuento(int descuento) {
        this.descuento = descuento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    public String getCanada() {
        return canada;
    }

    public void setCanada(String canada) {
        this.canada = canada;
    }

    public String getCostaRica() {
        return costaRica;
    }

    public void setCostaRica(String costaRica) {
        this.costaRica = costaRica;
    }

    public String getEua() {
        return eua;
    }

    public void setEua(String eua) {
        this.eua = eua;
    }

    public String getMexico() {
        return mexico;
    }

    public void setMexico(String mexico) {
        this.mexico = mexico;
    }

    public int getEquipos() {
        return equipos;
    }

    public void setEquipos(int equipos) {
        this.equipos = equipos;
    }

    public int getApuesta() {
        return apuesta;
    }

    public void setApuesta(int apuesta) {
        this.apuesta = apuesta;
    }

    public float getApuesta2() {
        return apuesta2;
    }

    public void setApuesta2(float apuesta2) {
        this.apuesta2 = apuesta2;
    }

    public int getApuesta3() {
        return apuesta3;
    }

    public void setApuesta3(int apuesta3) {
        this.apuesta3 = apuesta3;
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }
    
}

    

